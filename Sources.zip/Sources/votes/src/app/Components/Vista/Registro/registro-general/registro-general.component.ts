import { Component, OnInit } from '@angular/core';

import { UploaderService } from "src/app/Servicios/uploader.service";
import { ImagenesService } from "src/app/Servicios/imagenes.service";

@Component({
  selector: 'app-registro-general',
  templateUrl: './registro-general.component.html',
  styleUrls: ['./registro-general.component.css']
})
export class RegistroGeneralComponent implements OnInit {
  

  constructor(private uploadService: UploaderService,
    private imagenesService: ImagenesService
    ) { }

  ngOnInit() {
  }

  //Subir imagen
  selectedFile: ImageSnippet;
  
  fileChangeEvent(imageInput: any){
    console.log(imageInput);
      const file: File = imageInput.files[0];
      const reader = new FileReader();
      
      reader.addEventListener('load', (event: any) =>{
        this.selectedFile = new ImageSnippet(event.target.result, file);

        this.uploadService.postImagen(this.selectedFile.file)
          .subscribe(res => {
            //console.log(res['filename']);
            this.guardarImagen({imagen: res['filename']});
            //console.log(this.imagenes);
          }, error => console.log(error));
      });

      reader.readAsDataURL(file);
  }

  guardarImagen(imagen: any){
    console.log(imagen);
    this.imagenesService.postImagen(imagen)
      .subscribe(res => {
        console.log(res);
      });
  }

}

class ImageSnippet {
  constructor(public src: string, public file: File) {}
}