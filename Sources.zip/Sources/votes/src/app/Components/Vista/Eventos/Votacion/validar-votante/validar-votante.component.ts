import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {MatSnackBar} from '@angular/material';
import {RelojService} from 'src/app/Servicios/reloj.service';
import { Observable } from 'rxjs';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import { UsuarioService } from 'src/app/Servicios/usuario.service';
import { VotacionService } from 'src/app/Servicios/votacion.service';
import { MaquinaVotacionService } from 'src/app/Servicios/maquina-votacion.service';
import { BlockchainService } from 'src/app/Servicios/blockchain.service';

import { Usuario } from 'src/app/Modelo/usuario';
import { MaquinaVotacion } from 'src/app/Modelo/maquinaVotacion';
import { Votante } from 'src/app/Modelo/crearEdit';
import { Candidato } from "src/app/Modelo/candidato";
import { MaquinaDialogComponent } from '../../../MisDialogs/maquina-dialog/maquina-dialog.component';

@Component({
  selector: 'app-validar-votante',
  templateUrl: './validar-votante.component.html',
  styleUrls: ['./validar-votante.component.css']
})
export class ValidarVotanteComponent implements OnInit {
  idU: number;
  nombre: String;
  correo: String;
  noMaquina: String;
  estado: String;

  maquinas: MaquinaVotacion[];
  votante: Votante;
  
  idEvento: String;
  codigo: number;
  
  constructor(private route: ActivatedRoute,
    private usuarioService: UsuarioService,
    private votacionService: VotacionService,
    private maquinaVotacionService: MaquinaVotacionService,
    private blockchainService: BlockchainService,
    private snackBar: MatSnackBar,
    private reloj: RelojService,
    public dialog: MatDialog
    ) { 
      

    }

  ngOnInit() {
    this.idEvento = this.route.snapshot.paramMap.get('id');
    this.reloj.timeSecond.subscribe((now: Date) => {
      //console.log("tiempo", this.tiempo);
      this.getMaquinas();
    });
    
  }

  getMaquinas(){
    console.log(this.idEvento);
    this.maquinaVotacionService.getMaquinas(this.idEvento)
      .subscribe(res => {
        this.maquinas = res as MaquinaVotacion[];
        console.log(this.maquinas);
      });
  }

  getVotante(){
    this.votacionService.getVotante(this.idEvento, this.codigo)
      .subscribe(res => {
        this.votante = res['votantes'][0] as Votante;
        //console.log(this.votante);
        if (this.votante != null) {
          this.getUsuario(this.votante._id);
        }else{
          this.openSnackBar("Votante no registrado.", "Cerrar");
          this.limpiarinformacion();
        }
        
      });
  }

  getUsuario(id: number){
    this.usuarioService.getUsuario(id)
      .subscribe(res =>{
        this.usuarioService.usuario = res as Usuario;
        //console.log(res);
        this.idU = this.usuarioService.usuario._id;
        this.nombre = this.usuarioService.usuario.nombres+' '+this.usuarioService.usuario.apellidos;
        this.correo = this.usuarioService.usuario.correo;
        this.noMaquina = this.votante.maquina;
        this.asignarEstado();
        this.codigo = null;
      });
  }

  validarVotante(){
    if (this.estado === "No emitido") {
      let vo = [{votantes: [this.votante]}];
      console.log(vo);
      this.votacionService.deleteVotante(this.idEvento, vo)
        .subscribe(res => {
          console.log(res);
          this.votante.maquina = "A";
          let vo = [{votantes: [this.votante]}];
          console.log(vo);
          this.votacionService.addVotante
          this.votacionService.addVotante(this.idEvento, vo)
            .subscribe(res =>{
              console.log(res);
              this.limpiarinformacion();
              //this.addVotoVotante();
              
            });
        });
    }else{
      this.openSnackBar("No se puede asignar, voto emitido.", "Cerrar");
      
    }
    

  }

  asignarEstado(){
    if (this.votante.voto == "NE") {
      this.estado = "No emitido";
    }else{
      this.estado = "Emitido";
    }
  }

  asignarEstadoMaquina(estado: String){
    if (estado == "A") {
      return "Disponible";
    }else if (estado == "B") {
      return "Inactiva";
    }else{
      return "En uso"
    }
  }
/*
  addVotoVotante(){
    this.blockchainService.postVotante(this.idU, this.nombre)
      .subscribe(res => {
        console.log(res);
      });
    

    this.votacionService.getCandidatos(this.idEvento.toString())
      .subscribe(res =>{
        this.votacionService.candidatos = res as Candidato[];
        //console.log(this.votacionService.candidatos)
        for (const can of this.votacionService.candidatos) {
          this.blockchainService.postVoto(this.idU, this.idEvento, can.rol, can._id)
            .subscribe(res => {
              console.log(res);
              this.limpiarinformacion();
            });    
        }
        
      });
  }*/

  limpiarinformacion(){
    this.idU = null;
    this.nombre = "";
    this.correo = "";
    this.noMaquina = "";
    this.estado = "";
  }

  
  openDialog(ma: String, pass: String): void {
    const dialogRef = this.dialog.open(MaquinaDialogComponent, {
      data: {maquina: ma, password: pass}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
  

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }
}


