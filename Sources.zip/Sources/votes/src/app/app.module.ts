import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from "@angular/http";
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginAComponent } from './Components/Login/login-a/login-a.component';
import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MaterialModule } from './material';

import { MenuSidenavComponent } from './Components/Home/menu-sidenav/menu-sidenav.component';
import { PrincipalComponent } from './Components/Vista/Eventos/principal/principal.component';
import { InformacionComponent } from './Components/Vista/Eventos/Votacion/informacion/informacion.component';
import { Router } from '@angular/router';
import { ResumenVotacionComponent } from './Components/Vista/Eventos/Votacion/resumen-votacion/resumen-votacion.component';
import { PruebaComponent } from './Pruebas/prueba/prueba.component';
import { CrearEditarEventoComponent } from './Components/Vista/Eventos/Votacion/crear-editar-evento/crear-editar-evento.component';
import { EditarEventoComponent } from './Components/Vista/Eventos/Votacion/editar-evento/editar-evento.component';
import { ModoPresentacionComponent } from './Components/Vista/Eventos/Votacion/modo-presentacion/modo-presentacion.component';
import { HomeComponent } from './Components/Home/home/home.component';
import { RegistroComponent } from './Components/Vista/Eventos/Votacion/registro/registro.component';
import { EmitirVotacionComponent } from './Components/Vista/Eventos/Votacion/emitir-votacion/emitir-votacion.component';
import { LoginBComponent } from './Components/Login/login-b/login-b.component';
import { ValidarVotanteComponent } from './Components/Vista/Eventos/Votacion/validar-votante/validar-votante.component';
import { ImageUploadModule } from "angular2-image-upload";
import { RegistroGeneralComponent } from './Components/Vista/Registro/registro-general/registro-general.component';
import { MaquinaDialogComponent } from './Components/Vista/MisDialogs/maquina-dialog/maquina-dialog.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginAComponent,
    MenuSidenavComponent,
    PrincipalComponent,
    InformacionComponent,
    ResumenVotacionComponent,
    PruebaComponent,
    CrearEditarEventoComponent,
    EditarEventoComponent,
    ModoPresentacionComponent,
    HomeComponent,
    RegistroComponent,
    EmitirVotacionComponent,
    LoginBComponent,
    ValidarVotanteComponent,
    RegistroGeneralComponent,
    MaquinaDialogComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ImageUploadModule.forRoot(),
    HttpModule
    
  ],
  entryComponents:[
    MaquinaDialogComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
