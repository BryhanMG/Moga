export class Usuario{
    _id: number;
    nombres: String;
    apellidos: String;
    correo: String;


    constructor(){
        this._id = 0;
        this.nombres= '';
        this.apellidos = '';
        this.correo = '';
    }
}