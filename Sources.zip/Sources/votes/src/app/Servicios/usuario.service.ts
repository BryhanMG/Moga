import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Usuario } from '../Modelo/usuario';
import { LocalHost } from '../Modelo/Localhost';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  readonly URL_API = 'http://'+LocalHost+':3100/api/usuarios';
  usuario: Usuario;

  constructor(private http: HttpClient) { }

  //Obtener la informacion de un candidato (informacion del usuario)
  getUsuario(id: number){
    return this.http.get(this.URL_API + `/get/${id}`);
  }

  
}
