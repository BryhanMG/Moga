import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { LoginService } from "src/app/Servicios/login.service";
import { UserService } from "src/app/Servicios/user.service";
import { User } from 'src/app/Modelos/user';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  usuario: String = null;
  password: String = null;
  mensaje: String;

  constructor(private router: Router,
    private loginService: LoginService,
    private userService: UserService
    ) { }

  ngOnInit() {
  }

  login(){
    //console.log("Hola mundo");
    this.loginService.getAdmin(this.usuario)
      .subscribe(res => {
        var cuenta = res as Object;
        if (this.usuario == null || this.password == null || this.usuario.length == 0 || this.password.length == 0) {
          this.mensaje = "Campos vacíos.";
        }else if (this.password === cuenta["password"]) {
          //console.log("Secion iniciada para ", this.usuario);  
          let u: User = {username: this.usuario};        
          this.userService.setUserLoggedIn(u);
          this.router.navigateByUrl('/moga');
          this.mensaje = null;
        }else{
          //console.log("Usuario o contraseña incorrectos.");
          this.mensaje = "Usuario o contraseña incorrectos.";
        }
        
      });
  }

}
