import { Component, OnInit } from '@angular/core';

import { UserService } from "src/app/Servicios/user.service";
import {Location} from '@angular/common';

import { User } from "src/app/Modelos/user";
@Component({
  selector: 'app-menu-sidenav',
  templateUrl: './menu-sidenav.component.html',
  styleUrls: ['./menu-sidenav.component.css']
})
export class MenuSidenavComponent implements OnInit {
  usuario: String;
  userLogged: User;
  showHome: boolean = true;

  shouldRun = [/(^|\.)plnkr\.co$/, /(^|\.)stackblitz\.io$/].some(h => h.test(window.location.host));

  constructor(private locacion: Location,
    private userService: UserService) { }

  ngOnInit() {
    this.userLogged = this.userService.getUserLoggedIn();
    if (!this.userLogged) {
      //this.locacion.back();
    }else{
      this.usuario = this.userLogged.username;
    }
  }

  changeShowHome(){
    console.log("Si cambia");
    this.showHome = false;
    
  }

  cerrarSesion(){
    this.userService.closeSession();
    this.locacion.back();
  }
}
