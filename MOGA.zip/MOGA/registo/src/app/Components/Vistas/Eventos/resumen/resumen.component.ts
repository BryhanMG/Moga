import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { RegistroService } from "src/app/Servicios/registro.service";
import { ActividadService } from "src/app/Servicios/actividad.service";
import {RelojService} from 'src/app/Servicios/reloj.service';

import { EventoRegistro } from 'src/app/Modelos/eventoRegistro';
import { ActividadNuevaLibre, Actividad } from "src/app/Modelos/actividad";

import { UserService } from 'src/app/Servicios/user.service';
import {Location} from '@angular/common';

import { User } from "src/app/Modelos/user";


@Component({
  selector: 'app-resumen',
  templateUrl: './resumen.component.html',
  styleUrls: ['./resumen.component.css']
})
export class ResumenComponent implements OnInit {
  evento = new EventoRegistro; //evento que se esta creando
  listaActividades = [];
  tiempo: Date;
  idEvento: String;
  userLogged: UserService;
  estado: String;
  nombre_er: String;
  
  constructor(private reloj: RelojService,
    private route: ActivatedRoute,
    private eventoService: RegistroService,
    private actividadService: ActividadService,
    private locacion: Location,
    private userService: UserService
    ) {
      this.userLogged = this.userService.getUserLoggedIn();
      if (!this.userLogged) {
        this.locacion.back();
      }
      
      
      this.reloj.time.subscribe((now: Date) => {
        this.tiempo = now;
        console.log("tiempo Resumen", this.tiempo);
        this.comprobarActividadesEspera();
        this.obtenerEvento(this.idEvento);
      });
      
     }

  ngOnInit() {
    this.idEvento = this.route.snapshot.paramMap.get('id')
    this.obtenerEvento(this.idEvento);
    this.obtenerActividades(this.idEvento);
  }

  obtenerEvento(id){
    this.eventoService.getEvento(id)
      .subscribe(res =>{
        this.evento = res as EventoRegistro;
        //console.log(this.evento);
        if (this.evento) {
          this.estado = this.evento.estado;
          this.nombre_er = this.evento.nombre_er;  
        }
        
      });
  }

  obtenerActividades(id: String){
    //this.listaActividades = [];
    this.actividadService.getActividades(id)
      .subscribe(res => {
        var la = res as Actividad[];
        this.listaActividades = [];
        for (const a of la) {
          this.listaActividades.push({id: a._id, actividad: a});
        }
        this.comprobarActividadesEspera();
        //console.log(this.listaActividades);
      });
  }

  obtenerTipoActividad(tipo: number){
    if (tipo == 0) {
      return "Libre";
    }
  }

  comprobarActividadesEspera(){
    this.tiempo = new Date();
    if(this.listaActividades){
      for (const ac of this.listaActividades) {
        var fechaI = new Date(ac["actividad"]["fecha_i"].toString());
        var fechaF = new Date(ac["actividad"]["fecha_f"].toString());
        fechaI.setHours(fechaI.getHours()+6);
        fechaF.setHours(fechaF.getHours()+6);
        
        //console.log("Fecha inicial: ",fi);
        //console.log(fechaI," <= ", this.tiempo);
        //console.log(ff.valueOf()," >= ", this.tiempo.valueOf());
        if ( ac["actividad"]["estado"] === "E" && (fechaI <= this.tiempo && fechaF >= this.tiempo)) {
          ac["actividad"]["estado"] = "A";
          this.actividadService.updateActividad(ac["id"], ac["actividad"])
            .subscribe(res => {
              this.obtenerActividades(this.idEvento);
            });
        }else if ( (ac["actividad"]["estado"] === "E" || ac["actividad"]["estado"] === "A") && fechaF <= this.tiempo) {
          ac["actividad"]["estado"] = "T";
          this.actividadService.updateActividad(ac["id"], ac["actividad"])
            .subscribe(res => {
              this.obtenerActividades(this.idEvento);
            });
        }
      }
    }
  }

}
