export class User {
    username: String;   
}