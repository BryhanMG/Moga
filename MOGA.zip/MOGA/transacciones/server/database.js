const mongoose = require('mongoose');

//direccion de la base de datos
const URI = 'mongodb://localhost:27017/moga';
//const URI = 'mongodb://127.0.0.1:27017/moga';
//const URI = 'mongodb://192.168.1.10:27017/moga';
mongoose.connect(URI)
    .then(db => console.log('BD esta conectada'))
    .catch(err => console.error(err)); 

module.exports = mongoose;