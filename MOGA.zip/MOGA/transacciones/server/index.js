const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
//const bodyParser = require("body-parser");
//const fileUpload = require('express-fileupload')
const path = require('path');
const multer = require('multer');
const app = express();


const { mongoose } = require('./database');

// Settings
app.set('port', process.env.PORT || 3100);

// Middlewares
app.use(morgan('dev'));
app.use(express.json());
app.use(cors({origin: 'http://localhost:4200'}));
//app.use(cors({origin: 'http://192.168.1.10:4200'}));

// Routes
app.use('/api/usuarios',require('./routes/usuarios.routes'));
app.use('/api/eventos', require('./routes/eventos.routes'));
app.use('/api/eventos_r', require('./routes/eventos_rp.routes'));
app.use('/api/roles', require('./routes/roles.routes'));
app.use('/api/admins', require('./routes/administradores.routes'));
app.use('/api/admins_reg', require('./routes/administradores_reg.routes'));
app.use('/api/candidatos', require('./routes/condidatos.routes'));
app.use('/api/maquinas', require('./routes/maquinas.routes'));
app.use('/api/actividades', require('./routes/actividades.routes'));
app.use('/api/imagenes', require('./routes/imagenes.routes'));
app.use('/api/login', require('./routes/login.routes'));

//Upload
let storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './moga/src/assets/upload');
    },
    filename: (req, file, cb) =>{
        cb(null, file.filename + '-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({storage});

app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.get('/api/getImg', (req, res) => {
     return res.send('This is the home page!');
});

app.post('/api/upload', upload.single('file'), (req, res) => {
    console.log(`Storage location is ${req.hostname}/${req.file.path}`);
    console.log(req.file);
    return res.send(req.file);
});


// Empezar el servidor
app.listen(app.get('port'), () => {
    console.log('Server on port: ', app.get('port'));
});













