const express = require('express');
const router = express.Router();

const Actividades = require('../controllers/actividad.controller')

router.get('/get/', Actividades.getActividades);
router.get('/get/:id', Actividades.getActividad);
router.get('/getall-P/:id', Actividades.getAllParticipantes);
router.post('/create/', Actividades.crearActividad);
router.get('/getall/:id', Actividades.getAllActividadesEditar);
router.put('/update/:id', Actividades.updateActividad);
router.delete('/delete/:id', Actividades.deleteActividad);
router.put('/add/:id', Actividades.addParticipante);
router.put('/quit/:id', Actividades.quitParticipante);

module.exports = router;