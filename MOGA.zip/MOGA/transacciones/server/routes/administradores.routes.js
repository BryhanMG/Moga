const express = require('express');
const router = express.Router();

const admin = require('../controllers/administrador.controller')

router.get('/get/', admin.getAdmins);
router.get('/get/:id', admin.getAdmin);
router.post('/create/', admin.crearAdmin);
router.get('/getAE/', admin.getAdminsEventos);
router.put('/addEvento/:id', admin.addAdminEvento);
router.put('/updateEventos/:id', admin.updateAdminEventos);
router.put('/updatePass/:id', admin.updateAdminPass);
router.delete('/delete/:id', admin.deleteAdmin);

module.exports = router;