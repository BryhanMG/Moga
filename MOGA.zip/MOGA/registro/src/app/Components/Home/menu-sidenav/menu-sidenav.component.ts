import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

import { UserService } from "src/app/Servicios/user.service";
import {Location} from '@angular/common';

import { User } from "src/app/Modelos/user";
import { UsuarioService } from 'src/app/Servicios/usuario.service';
import { CambiarPasswordDialogComponent } from '../../Vistas/MisDialogs/cambiar-password-dialog/cambiar-password-dialog.component';
import { AdministradorService } from 'src/app/Servicios/administrador.service';
import { Administrador } from 'src/app/Modelos/administrador';
@Component({
  selector: 'app-menu-sidenav',
  templateUrl: './menu-sidenav.component.html',
  styleUrls: ['./menu-sidenav.component.css']
})
export class MenuSidenavComponent implements OnInit {
  idUser: String;
  usuario: String;
  userLogged: User;
  showHome: boolean = true;

  shouldRun = [/(^|\.)plnkr\.co$/, /(^|\.)stackblitz\.io$/].some(h => h.test(window.location.host));

  constructor(private locacion: Location,
    private userService: UserService,
    private usuarioService: UsuarioService,
    private administradorService: AdministradorService,
    public dialog: MatDialog,) { }

  ngOnInit() {
    this.userLogged = this.userService.getUserLoggedIn();
    if (!this.userLogged) {
      //this.locacion.back();
    }else{
      this.idUser = this.userLogged.username;
      this.obtenerUsuario(this.userLogged.username);
    }
  }

  obtenerUsuario(id: String){
    this.usuarioService.getUsuario(id)
      .subscribe(res => {
        this.usuario = res['nombres'];
      });
    
  }

  changeShowHome(){
    console.log("Si cambia");
    this.showHome = false;
    
  }

  cerrarSesion(){
    this.userService.closeSession();
    this.locacion.back();
  }

  //Dialog para cambiar la contraseña del usuario
  passwordDialog(): void {
    
    const dialogRef = this.dialog.open(CambiarPasswordDialogComponent, {
      data: {idUser: this.idUser
        }
    });

    dialogRef.afterClosed().subscribe(result => {
      
      console.log('The dialog was closed');
      if (result) {
        
      }
    });
  }
}
