import { Component, OnInit, OnDestroy } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

import { UserService } from "src/app/Servicios/user.service";
import {Location} from '@angular/common';

import { User } from "src/app/Modelos/user";
import { UsuarioService } from 'src/app/Servicios/usuario.service';
import { CambiarPasswordDialogComponent } from '../../Vistas/MisDialogs/cambiar-password-dialog/cambiar-password-dialog.component';
import { AdministradorService } from 'src/app/Servicios/administrador.service';
import { Administrador } from 'src/app/Modelos/administrador';
import { Router } from '@angular/router';
import { RelojService } from 'src/app/Servicios/reloj.service';
@Component({
  selector: 'app-menu-sidenav',
  templateUrl: './menu-sidenav.component.html',
  styleUrls: ['./menu-sidenav.component.css']
})
export class MenuSidenavComponent implements OnInit, OnDestroy {
  idUser: String;
  usuario: String;
  userLogged: User;
  showHome: boolean = true;

  shouldRun = [/(^|\.)plnkr\.co$/, /(^|\.)stackblitz\.io$/].some(h => h.test(window.location.host));

  //Temporizadores
  private r1Subsciption;

  constructor(private locacion: Location,
    private userService: UserService,
    private usuarioService: UsuarioService,
    private administradorService: AdministradorService,
    public dialog: MatDialog,
    private router: Router,
    private reloj: RelojService,
    ) { 
      this.r1Subsciption = this.reloj.timeSecondSession.subscribe((now: Date) => {
        this.userLogged = this.userService.getUserLoggedIn();
        if (!this.userLogged) {
          this.router.navigateByUrl('/error-logout');
        }
      });
    }

  ngOnInit() {
    this.userLogged = this.userService.getUserLoggedIn();
    if (this.userLogged) {
      this.idUser = this.userLogged.username;
      this.obtenerUsuario(this.userLogged.username); 
    }
  }

  ngOnDestroy(): void {
    this.r1Subsciption.unsubscribe();
  }

  obtenerUsuario(id: String){
    this.usuarioService.getUsuario(id)
      .subscribe(res => {
        if (res != null) {
          this.usuario = res['nombres'];  
        }
      });
    
  }

  changeShowHome(){
    console.log("Si cambia");
    this.showHome = false;
    
  }

  cerrarSesion(){
    this.userService.closeSession();
    this.router.navigateByUrl('/login');
  }

  //Dialog para cambiar la contraseña del usuario
  passwordDialog(): void {
    
    const dialogRef = this.dialog.open(CambiarPasswordDialogComponent, {
      data: {idUser: this.idUser
        }
    });

    dialogRef.afterClosed().subscribe(result => {
      
    });
  }
}
