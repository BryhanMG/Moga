import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ActividadService } from "src/app/Servicios/actividad.service";
import {RelojService} from 'src/app/Servicios/reloj.service';
import { Actividad } from 'src/app/Modelos/actividad';

import { UserService } from 'src/app/Servicios/user.service';
import {Location} from '@angular/common';

import { User } from "src/app/Modelos/user";


@Component({
  selector: 'app-registro-participante',
  templateUrl: './registro-participante.component.html',
  styleUrls: ['./registro-participante.component.css']
})
export class RegistroParticipanteComponent implements OnInit {
  nombre: String = null;
  correo: String = null;
  nombreT: String = null;
  correoT: String = null;
  buscar: String = null;
  bloqueo = false;
  estado: String;

  listaAsistentes= [];
  listaBuscar= [];
  idActividad: String;
  userLogged: UserService;
  constructor(private reloj: RelojService,
    private route: ActivatedRoute,
    private actividadService: ActividadService,
    private locacion: Location,
    private userService: UserService
    ) {
      this.userLogged = this.userService.getUserLoggedIn();
      if (!this.userLogged) {
        this.locacion.back();
      }

      this.reloj.time.subscribe((now: Date) => {
        console.log("tiempo", now);
        this.obtenerActividad();
      });
     }

  ngOnInit() {
    this.idActividad = this.route.snapshot.paramMap.get('id');
    this.obtenerAsistentes(this.idActividad);
    this.obtenerActividad();
  }

  obtenerAsistentes(id: String){
    this.listaAsistentes = [];
    this.listaBuscar = [];
    this.actividadService.getAsistentes(id)
      .subscribe(res => {
        var temp = res[0]["asistentes"] as Object[];
        for (const i of temp) {
          this.listaAsistentes.push({nombre: i["nombre"], correo: i["correo"]})
          this.listaBuscar.push({nombre: i["nombre"], correo: i["correo"]})
        }
        console.log(this.listaAsistentes);
      });
  }

  obtenerActividad(){
    this.actividadService.getActividad(this.idActividad)
      .subscribe(res => {
        console.log(res);
        var actividad = res as Actividad;
        if (actividad != null) {
          if (actividad["estado"] === "A") {
            this.bloqueo = false;
          }else{
            this.bloqueo = true;
            this.limpiarCampos();
          }
          this.obtenerEstado(res["estado"]);
        }
        
      });
  }

  obtenerEstado(estado: String){
    if (estado === "E") {
      this.estado = "En espera";
    }else if (estado === "A") {
      this.estado = "Activo";
    }else if (estado === "T") {
      this.estado = "Terminado";
    }
  }

  flagEdit = false;
  registrar(){
    if (this.nombre != null) {
      if (!this.flagEdit) {
        var asistente = [{asistentes: [{nombre: this.nombre, correo: this.correo}]}];
        this.actividadService.putAsistente(this.idActividad, asistente)
          .subscribe(res => {
            console.log(res);
            this.obtenerAsistentes(this.idActividad);
            this.limpiarCampos();
          });  
      }else{
        this.eliminarEdicion();
      }

        
    }
    
  }

  eliminarEdicion(){
    var nombre = this.nombreT;
    var correo = this.correoT;
    var asistente = [{asistentes: [{nombre: nombre, correo: correo}]}];
    this.actividadService.deleteAsistente(this.idActividad, asistente)
      .subscribe(res => {
        console.log(res);
        
          this.flagEdit = false;
          this.registrar();  
        
      });  
  }

  eliminar(nombre: String, correo: String){
    var asistente = [{asistentes: [{nombre: nombre, correo: correo}]}];
    this.actividadService.deleteAsistente(this.idActividad, asistente)
      .subscribe(res => {
        console.log(res);
        this.obtenerAsistentes(this.idActividad);
      });
  }

  editar(nombre: String, correo: String){
    this.nombre = nombre;
    this.correo = correo;
    this.nombreT = nombre;
    this.correoT = correo;
    this.flagEdit = true;

  }

  limpiarCampos(){
    this.nombre = null;
    this.correo = null;
    this.nombreT = null;
    this.correoT = null;
  }

  buscarNombre(){
    var lista = [];
    for (const a of this.listaBuscar) {
      //console.log(ev.nombre_er);
      console.log(a["nombre"]);
      if (a["nombre"].includes(this.buscar)) {
        lista.push(a);
      }
    }
    if (this.buscar.length == 0) {
      this.obtenerAsistentes(this.idActividad);
    }else{
      this.listaAsistentes = lista;
    }
    
  }

  actualizar(){
    this.obtenerAsistentes(this.idActividad);
  }

}
