import { Component, OnInit } from '@angular/core';

import { EventoRegistro } from "src/app/Modelos/eventoRegistro";

import { RegistroService } from "src/app/Servicios/registro.service";
import {RelojService} from 'src/app/Servicios/reloj.service';

import { UserService } from 'src/app/Servicios/user.service';
import {Location} from '@angular/common';

import { User } from "src/app/Modelos/user";


@Component({
  selector: 'app-informacion',
  templateUrl: './informacion.component.html',
  styleUrls: ['./informacion.component.css']
})
export class InformacionComponent implements OnInit {
  listaEventos: EventoRegistro[];
  listaOpcion: EventoRegistro[];
  estado="";
  mostrar="Z";
  entrada="";
  tiempo: Date;
  userLogged: UserService;

  constructor(private reloj: RelojService,
    private eventoService: RegistroService,
    private locacion: Location,
    private userService: UserService
    ) { 
      this.userLogged = this.userService.getUserLoggedIn();
      if (!this.userLogged) {
        this.locacion.back();
      }
      this.reloj.time.subscribe((now: Date) => {
        this.tiempo = now;
        console.log("tiempo", this.tiempo);
        this.comprobarEventosEspera();
        this.evaluarEventos();
      });
    }

  ngOnInit() {
    
    this.getEventos();
    
  }

  getEventos(){
    this.eventoService.getEventos()
      .subscribe(res =>{
        this.listaEventos = res as EventoRegistro[];
        this.listaOpcion = res as EventoRegistro[];
        //console.log(this.listaEventos);
      });
  }

  indentificarEstado(estado: string): String{
    this.estado = estado;
    if (estado === "A") {
      return "A";
    }
    return "N";
  }

  opcionMostrar(){
    //console.log("opcion: "+this.mostrar);
    var lista = [];
    if(this.mostrar === 'Z'){
      this.listaEventos = this.listaOpcion;
    }else{
      for (const ev of this.listaOpcion) {
        //console.log("estado A: "+ev.estado + " estado B: "+this.mostrar);

        if (this.mostrar === ev.estado) {
          lista.push(ev);
        }
      }
      this.listaEventos = lista;
    }
    //console.log(lista);
  }

  buscar(){
    var lista = [];
    for (const ev of this.listaOpcion) {
      console.log(ev.nombre_er);
      console.log(this.entrada);
      if (ev.nombre_er.includes(this.entrada) || ev._id.includes(this.entrada)) {
        lista.push(ev);
      }
    }
    this.listaEventos = lista;
  }

  comprobarEventosEspera(){
    if(this.listaOpcion){
      for (const ev of this.listaOpcion) {
        var fechaI = new Date();
        var fechaF = new Date();
        fechaI.setFullYear(+ev.fecha_i.toString().substring(0, 4));
        fechaI.setMonth((+ev.fecha_i.toString().substring(5, 7)-1));
        fechaI.setDate((+ev.fecha_i.toString().substring(8, 10)));
        fechaI.setHours(+ev.fecha_i.toString().substring(11, 13));
        fechaI.setMinutes(+ev.fecha_i.toString().substring(14, 16));
        fechaF.setFullYear(+ev.fecha_f.toString().substring(0, 4));
        fechaF.setMonth((+ev.fecha_f.toString().substring(5, 7)-1));
        fechaF.setDate((+ev.fecha_f.toString().substring(8, 10)));
        fechaF.setHours(+ev.fecha_f.toString().substring(11, 13));
        fechaF.setMinutes(+ev.fecha_f.toString().substring(14, 16));
        //console.log("Fecha inicial: ",fi);
        //console.log(fi.valueOf()," <= ", this.tiempo.valueOf());
        //console.log(ff.valueOf()," >= ", this.tiempo.valueOf());
        if ( ev.estado === "E" && (fechaI.valueOf() <= this.tiempo.valueOf() && fechaF.valueOf() >= this.tiempo.valueOf())) {
          //console.log(fechaI," <= ", this.tiempo);
          //console.log("Actualizar evento", ev._id)
          ev.estado = "A";
          this.eventoService.updateEvento(ev)
            .subscribe(res => {
              console.log(res);
              this.getEventos();
            });
        }

        if ( (ev.estado === "A" || ev.estado === "E") && fechaF.valueOf() <= this.tiempo.valueOf()) {
          //console.log(fechaI," <= ", this.tiempo);
          //console.log("Actualizar evento", ev._id)
          ev.estado = "T";
          this.eventoService.updateEvento(ev)
            .subscribe(res => {
              console.log(res);
              this.getEventos();
            });
        }
      }
    }
    
    
  }

  evaluarEventos(){
    this.eventoService.getEventos()
      .subscribe(res => {
        this.listaOpcion = res as EventoRegistro[];
        console.log(this.listaOpcion[0]["nombre_er"]);
        if ((this.listaOpcion && this.listaEventos) && this.listaOpcion.length == this.listaEventos.length) {
          for (const ev of this.listaOpcion) {
            for (const e of this.listaEventos) {
              if (ev._id === e._id) {
                if (ev !== e) {
                  e.nombre_er = ev.nombre_er;
                  e.fecha_i = ev.fecha_i;
                  e.fecha_f = ev.fecha_f;
                  e.estado = ev.estado;
                  e.tipo = ev.tipo;
                  e.descripcion = ev.descripcion;
                }
              }
            }
          }  
        }else{
         this.listaEventos = this.listaOpcion; 
        }
        
      });
  }

}
