import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-autenticacion',
  templateUrl: './autenticacion.component.html',
  styleUrls: ['./autenticacion.component.css'],

})
export class AutenticacionComponent implements OnInit {
  
  
  constructor() {  
  } 

  ngOnInit() {
  }


  
}
