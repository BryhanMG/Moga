import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { RegistroService } from "src/app/Servicios/registro.service";
import { ActividadService } from "src/app/Servicios/actividad.service";
import {RelojService} from 'src/app/Servicios/reloj.service';

import { EventoRegistro } from 'src/app/Modelos/eventoRegistro';
import { ActividadNuevaLibre, Actividad } from "src/app/Modelos/actividad";

import { UserService } from 'src/app/Servicios/user.service';
import {Location} from '@angular/common';

import { User } from "src/app/Modelos/user";


@Component({
  selector: 'app-resumen',
  templateUrl: './resumen.component.html',
  styleUrls: ['./resumen.component.css']
})
export class ResumenComponent implements OnInit {
  evento = new EventoRegistro; //evento que se esta creando
  listaActividades = [];
  tiempo: Date;
  idEvento: String;
  userLogged: UserService;
  estado: String;
  nombre_er: String;
  
  constructor(private reloj: RelojService,
    private route: ActivatedRoute,
    private eventoService: RegistroService,
    private actividadService: ActividadService,
    private locacion: Location,
    private userService: UserService
    ) {
      this.userLogged = this.userService.getUserLoggedIn();
      if (!this.userLogged) {
        this.locacion.back();
      }

      this.reloj.time.subscribe((now: Date) => {
        this.tiempo = now;
        console.log("tiempo Resumen", this.tiempo);
        this.comprobarActividadesEspera();
        this.obtenerEvento(this.idEvento);
      });
     }

  ngOnInit() {
    this.idEvento = this.route.snapshot.paramMap.get('id')
    this.obtenerEvento(this.idEvento);
    this.obtenerActividades(this.idEvento);
  }

  obtenerEvento(id){
    this.eventoService.getEvento(id)
      .subscribe(res =>{
        this.evento = res as EventoRegistro;
        //console.log(this.evento);
        if (this.evento) {
          this.estado = this.evento.estado;
          this.nombre_er = this.evento.nombre_er;  
        }
        
      });
  }

  obtenerActividades(id: String){
    this.listaActividades = [];
    this.actividadService.getActividades(id)
      .subscribe(res => {
        var la = res as Actividad[];
        for (const a of la) {
          this.listaActividades.push({id: a._id, actividad: a});
        }
        //console.log(this.listaActividades);
      });
  }

  obtenerTipoActividad(tipo: number){
    if (tipo == 0) {
      return "Libre";
    }
  }

  comprobarActividadesEspera(){
    if(this.listaActividades){
      for (const ac of this.listaActividades) {
        var fechaI = new Date();
        var fechaF = new Date();
        //console.log("fecha inicio: ",ac["actividad"]["fecha_i"]);
        fechaI.setFullYear(+ac["actividad"]["fecha_i"].toString().substring(0, 4));
        fechaI.setMonth((+ac["actividad"]["fecha_i"].toString().substring(5, 7)-1));
        fechaI.setDate((+ac["actividad"]["fecha_i"].toString().substring(8, 10)));
        fechaI.setHours(+ac["actividad"]["fecha_i"].toString().substring(11, 13));
        fechaI.setMinutes(+ac["actividad"]["fecha_i"].toString().substring(14, 16));
        fechaF.setFullYear(+ac["actividad"]["fecha_f"].toString().substring(0, 4));
        fechaF.setMonth((+ac["actividad"]["fecha_f"].toString().substring(5, 7)-1));
        fechaF.setDate((+ac["actividad"]["fecha_f"].toString().substring(8, 10)));
        fechaF.setHours(+ac["actividad"]["fecha_f"].toString().substring(11, 13));
        fechaF.setMinutes(+ac["actividad"]["fecha_f"].toString().substring(14, 16));
        //console.log("Fecha inicial: ",fi);
        //console.log(fechaI," <= ", this.tiempo);
        //console.log(ff.valueOf()," >= ", this.tiempo.valueOf());
        if ( ac["actividad"]["estado"] === "E" && (fechaI.valueOf() <= this.tiempo.valueOf() && fechaF.valueOf() >= this.tiempo.valueOf())) {
          //console.log(fechaI," <= ", this.tiempo);
          //console.log("Actualizar evento", ev._id)
          ac["actividad"]["estado"] = "A";
          this.actividadService.updateActividad(ac["id"], ac["actividad"])
            .subscribe(res => {
              console.log(res);
              this.obtenerActividades(this.idEvento);
            });
        }else if ( (ac["actividad"]["estado"] === "E" || ac["actividad"]["estado"] === "A") && fechaF.valueOf() <= this.tiempo.valueOf()) {
          //console.log(fechaI," <= ", this.tiempo);
          //console.log("Actualizar evento", ev._id)
          ac["actividad"]["estado"] = "T";
          this.actividadService.updateActividad(ac["id"], ac["actividad"])
            .subscribe(res => {
              console.log(res);
              this.obtenerActividades(this.idEvento);
            });
        }
      }
    }
  }

}
