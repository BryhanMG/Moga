import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EventoRegistro } from "src/app/Modelos/eventoRegistro"
import { Hostip } from "src/app/Modelos/hostip";

@Injectable({
  providedIn: 'root'
})
export class RegistroService {
  localhost = Hostip;
  //localhost = "192.168.1.11";
  //localhost = "192.168.43.116";
  readonly URL_API_EVENTO = 'http://'+this.localhost+':3100/api/eventos_r';

  conteo: number;

  constructor(private http: HttpClient) { }

  //Obtener todos los eventos de registro
  getEventos(){
    return this.http.get(this.URL_API_EVENTO+'/get/');
  }

  //Obtener un evento especifico
  getEvento(id: String){
    return this.http.get(this.URL_API_EVENTO+`/get/${id}`);
  }

  //Obtener la cantidad de eventos existentes
  getEventosCount(){
    return this.http.get(this.URL_API_EVENTO+'/getcount/');
  }

  //Crear un nuevo evento
  postEvento(evento: EventoRegistro){
    return this.http.post(this.URL_API_EVENTO+'/create/', evento);
  }

  updateEvento(evento: EventoRegistro){
    return this.http.put(this.URL_API_EVENTO+`/update/${evento._id}`, evento);
  }
}
