export class Usuario{
    _id: String;
    nombres: String;
    apellidos: String;
    correo: String;


    constructor(){
        this._id = '';
        this.nombres= '';
        this.apellidos = '';
        this.correo = '';
    }
}