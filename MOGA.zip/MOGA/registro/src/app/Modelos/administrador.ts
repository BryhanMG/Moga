export class Administrador{
    _id: String;
    password: String;
    
    constructor(){
        this._id="";
        this.password="";
    }
}