import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { AdministradorService } from 'src/app/Servicios/administrador.service';

@Component({
  selector: 'app-add-admin-dialog',
  templateUrl: './add-admin-dialog.component.html',
  styleUrls: ['./add-admin-dialog.component.css']
})
export class AddAdminDialogComponent implements OnInit {
  idUser: String;
  nombres: String;
  rolNombre: String;
  rol: number;

  password: String;

  constructor(public dialogRef: MatDialogRef<AddAdminDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private adminService: AdministradorService
    ) { }

  ngOnInit() {
    this.idUser = this.data["idUser"];
    this.nombres = this.data["nombres"];
    this.rolNombre = this.data["rolNombre"];
    this.rol = this.data["rol"];
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  addAdmin(){
    this.adminService.postAdministrador({
      _id: this.idUser,
      rol: this.rol,
      password: this.password
    }).subscribe(res => {
      console.log(res);
      this.dialogRef.close(true);
    });
  }

}
