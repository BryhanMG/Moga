import { Component, OnInit } from '@angular/core';
import {RelojService} from 'src/app/Servicios/reloj.service';
import { Observable } from 'rxjs';
import { CrearEdit } from 'src/app/Modelo/crearEdit';
import { EventoVotacion } from 'src/app/Modelo/eventoVotacion';

import { VotacionService } from 'src/app/Servicios/votacion.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  tiempo: Date;
  eventos: EventoVotacion[];

  constructor(
    ) { 
    
  }

  ngOnInit() {
  }

  

}
