export class MaquinaVotacion{
    _id: String = "";
    id_ev: String = "";
    numero: Number= null;
    codigo: String = "";
    estado: String = "";

    constructor(){
        this._id = "";
        this.id_ev = "";
        this.numero = null;
        this.codigo = "";
        this.estado = "";
    }
}

