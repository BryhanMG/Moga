export class Imagen{
    id: String;
    imagen: String;
}