export class InfoEvento{
    id:  String;
    nombre_ev: String;
    fecha_i: String;
    fecha_f: String;
    descripcion: String;
    estado: String;
}