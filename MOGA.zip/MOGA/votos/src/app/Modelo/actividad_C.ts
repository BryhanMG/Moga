export class Actividad_C{
    id:  number;
    nombre_a: String;
    fecha_i: String;
    fecha_f: String;
    descripcion: String;
    estado: String;
    tipo: number;
    total: number;
    participantes: Array<number>;
    

    constructor(id:number, nombre_a:String, fecha_i:String, fecha_f:String, descripcion:String,
         estado: String, tipo: number, total: number,participantes: Array<number>){
        
        this.id = id;
        this.nombre_a = nombre_a;
        this.fecha_i = fecha_i;
        this.fecha_f = fecha_f;
        this.descripcion = descripcion;
        this.estado = estado;
        this.tipo = tipo;
        this.total = total;
        this.participantes = participantes;

    }
}