export class User {
    username: String;
    tipo: number;
}