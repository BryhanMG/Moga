export class User {
    username: String;
    tipo: String;   
    eventos: [];
}