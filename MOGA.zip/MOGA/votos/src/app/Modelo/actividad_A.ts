export class Actividad_A{
    id:  number;
    nombre_a: String;
    fecha_i: String;
    fecha_f: String;
    descripcion: String;
    estado: String;
    tipo: number;
    
}