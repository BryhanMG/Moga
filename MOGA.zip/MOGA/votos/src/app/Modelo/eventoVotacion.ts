export class EventoVotacion{
    _id:  String;
    nombre_ev: String;
    fecha_i: String;
    fecha_f: String;
    descripcion: String;
    estado: String;
    

    constructor(){
        this._id= '';
        this.nombre_ev = '';
        this.fecha_i = '';
        this.fecha_f = '';
        this.descripcion = '';
        this.estado = '';
    }
}