import { Component, OnInit } from '@angular/core';
import {RelojService} from 'src/app/Servicios/reloj.service';
import { Observable } from 'rxjs';

import { CrearEdit } from 'src/app/Modelo/crearEdit';
import { EventoVotacion } from 'src/app/Modelo/eventoVotacion';
import { Candidato } from 'src/app/Modelo/candidato';
import { MaquinaVotacion } from 'src/app/Modelo/maquinaVotacion';

import { VotacionService } from 'src/app/Servicios/votacion.service';
import { BlockchainService } from "src/app/Servicios/blockchain.service";
import { MaquinaVotacionService } from "src/app/Servicios/maquina-votacion.service";



@Component({
  selector: 'app-menu-sidenav',
  templateUrl: './menu-sidenav.component.html',
  styleUrls: ['./menu-sidenav.component.css']
})
export class MenuSidenavComponent extends CrearEdit implements OnInit {
  showHome: boolean = true;
  opened: true;
  opcion: number=0;
  
  shouldRun = [/(^|\.)plnkr\.co$/, /(^|\.)stackblitz\.io$/].some(h => h.test(window.location.host));

  tiempo: Date;
  eventos: EventoVotacion[];
  candidatos: Candidato[];

  constructor(private reloj: RelojService,
    private votacionServicio: VotacionService,
    private blockchainService: BlockchainService,
    private maquinaService: MaquinaVotacionService
    ) {
    super();
    this.reloj.time.subscribe((now: Date) => {
      this.tiempo = now;
      //console.log("tiempo", this.tiempo);
      this.comprobarEventosEspera();

    });
  }

  ngOnInit() {
  }

  activarApartado(op: number){
     this.opcion = op;
  }

  changeShowHome(){
    console.log("Si cambia");
    this.showHome = false;
  }

  comprobarEventosEspera(){
    
    this.votacionServicio.getEventosRevision( "E")
      .subscribe(res => {
        this.eventos = res as EventoVotacion[];
        
        for (const evento of this.eventos) {
          //console.log(this.tiempo +">=" +new Date(evento.fecha_i.toString()));

          var fechaI = new Date();
          var fechaF = new Date();
          //console.log(evento.fecha_i.toString());
          //console.log(evento.fecha_i.toString().substring(5, 7));
          fechaI.setFullYear(+evento.fecha_i.toString().substring(0, 4));
          fechaI.setMonth((+evento.fecha_i.toString().substring(5, 7)-1));
          fechaI.setDate((+evento.fecha_i.toString().substring(8, 10)));
          fechaI.setHours(+evento.fecha_i.toString().substring(11, 13));
          fechaI.setMinutes((+evento.fecha_i.toString().substring(14, 16)-1));
          fechaF.setFullYear(+evento.fecha_f.toString().substring(0, 4));
          fechaF.setMonth((+evento.fecha_f.toString().substring(5, 7)-1));
          fechaF.setDate((+evento.fecha_f.toString().substring(8, 10)));
          fechaF.setHours(+evento.fecha_f.toString().substring(11, 13));
          fechaF.setMinutes(+evento.fecha_f.toString().substring(14, 16));
          //console.log(fechaF);
          //console.log(this.tiempo +">=" +fechaI);
          //console.log(evento.nombre_ev);
          //console.log(fechaF +"<=" +this.tiempo);
          if ( this.tiempo >= fechaI && this.tiempo <= fechaF) {
            //console.log("Se activa el evento: ", evento.nombre_ev);
            evento.estado = "A";
            this.cambiarEstadoEvento(evento);
            //this.candidatosBC(evento._id);
            this.actualizarMaquina(evento._id, "A");
          }
          //this.candidatosBC(evento._id);
          
        }
        

        
      });

      this.votacionServicio.getEventosRevision( "A")
        .subscribe(res => {
          this.eventos = res as EventoVotacion[];
          var fechaF = new Date();
          
          for (const evento of this.eventos) {
            fechaF.setFullYear(+evento.fecha_f.toString().substring(0, 4));
            fechaF.setMonth((+evento.fecha_f.toString().substring(5, 7)-1));
            fechaF.setDate((+evento.fecha_f.toString().substring(8, 10)));
            fechaF.setHours(+evento.fecha_f.toString().substring(11, 13));
            fechaF.setMinutes((+evento.fecha_f.toString().substring(14, 16)-1));
            if ( fechaF <= this.tiempo) {
              //console.log("Se termina el evento: ", evento.nombre_ev);
              evento.estado = "T";
              this.cambiarEstadoEvento(evento);
              this.actualizarMaquina(evento._id, "B");
            }
          }

          
        });

    
    
    
  }

  cambiarEstadoEvento(evento: EventoVotacion){

    this.votacionServicio.updateEstadoEvento(evento)
      .subscribe(res=>{
        console.log(res);
      });
    
    //
  }
/*
  candidatosBC(idE: String){
    this.votacionServicio.getCandidatos(idE.toString())
      .subscribe(res =>{
        this.candidatos = res as Candidato[]; 
        //console.log(this.candidatos);
        for (const rol of this.candidatos) {
          //console.log(rol);
          for (const can of rol.candidatos) {
            //console.log(can);
            this.blockchainService.postCandidato(can['_id'], idE, rol.rol)
              .subscribe(res => {
                console.log(res);
              });  
            
          }
            
        }
      });
  }*/

  actualizarMaquina(idE: String, estado: String){
    this.maquinaService.getMaquinas(idE)
      .subscribe(res => {
        this.maquinaService.maquinas = res as MaquinaVotacion[];
        console.log(this.maquinaService.maquinas);
        for (const maquina of this.maquinaService.maquinas) {
          maquina.estado = estado;
          this.maquinaService.upadeteMaquina(maquina._id, maquina)
            .subscribe(res => {
              console.log(res);
            });
        }
      });

    
  }
}
