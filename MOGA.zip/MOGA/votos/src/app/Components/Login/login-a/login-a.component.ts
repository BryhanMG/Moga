import { Component, OnInit } from '@angular/core';
import { BlockchainService } from 'src/app/Servicios/blockchain.service'


@Component({
  selector: 'app-login-a',
  templateUrl: './login-a.component.html',
  styleUrls: ['./login-a.component.css']
})
export class LoginAComponent implements OnInit {
  login = false;
  constructor(private blockchainService: BlockchainService) { }

  ngOnInit() {
   
    }

  ingresar(){
    this.login = true;
  }

  
  
  



}
