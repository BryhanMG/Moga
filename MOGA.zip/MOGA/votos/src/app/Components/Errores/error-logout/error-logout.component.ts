import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-logout',
  templateUrl: './error-logout.component.html',
  styleUrls: ['./error-logout.component.css']
})
export class ErrorLogoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
